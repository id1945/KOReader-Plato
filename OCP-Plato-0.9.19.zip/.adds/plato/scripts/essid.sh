#! /bin/sh

iwgetid -r
