local _ = require("gettext")
return {
    name = "readtimer",
    fullname = _("Read timer"),
    description = _([[Shows an alarm after a specified amount of time.]]),
}
