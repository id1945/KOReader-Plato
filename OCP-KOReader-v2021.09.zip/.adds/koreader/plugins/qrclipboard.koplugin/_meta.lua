local _ = require("gettext")
return {
    name = "qrclipboard",
    fullname = _("QR from clipboard"),
    description = _([[This plugin generates a QR code from clipboard content.]]),
}
