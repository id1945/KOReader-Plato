return {
    [102] = "Home",
    [105] = "Left",
    [106] = "Right",
    [357] = "Menu",
    [158] = "Back",
    [116] = "Power",
}
