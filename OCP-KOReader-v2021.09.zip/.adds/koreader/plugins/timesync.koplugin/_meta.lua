local _ = require("gettext")
return {
    name = "timesync",
    fullname = _("Time sync"),
    description = _([[Synchronizes the device time with NTP servers.]]),
}
