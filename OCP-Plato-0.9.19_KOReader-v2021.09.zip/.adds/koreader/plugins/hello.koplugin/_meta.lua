local _ = require("gettext")
return {
    name = "hello",
    fullname = _("Hello"),
    description = _([[This is a debugging plugin.]]),
}
